using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BacteriaScript : MonoBehaviour
{

    public BacteriaSpawner bacteriaSpawner;
    public GameObject game_area;

    public float speed;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Move();
    }


    void Move()
	{
		if(game_area != null)
		{
			transform.position += transform.up * (Time.deltaTime * speed);

			float distance = Vector3.Distance(transform.position, game_area.transform.position);
			if(distance > bacteriaSpawner.death_circle_radius){
				RemoveObject();
			}
		}
    }

    void RemoveObject(){
        Destroy(gameObject);
        bacteriaSpawner.count -= 1;
    }


}
