using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BacteriaMovement : MonoBehaviour
{
    [SerializeField]
    float rotationSpeed;
    [SerializeField]
    GameObject pivotObject;
    [SerializeField]
    Vector3 rotateAxis;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.RotateAround(pivotObject.transform.position, rotateAxis, rotationSpeed * Time.deltaTime);
    }
}
