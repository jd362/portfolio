using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class ScaleEnvironment : MonoBehaviour
{

    [SerializeField]
    private Vector3 normalScale = new Vector3(1f, 1f, 1f);
    [SerializeField]
    private Vector3 largeScale = new Vector3(1000f, 1000f, 1000f);
    [SerializeField]
    private float duration = 7f;


    public bool activateChangeScale = true;
    GameObject environment;
    GameObject player;
    GameObject bigParticles;
    GameObject centerEyeAnchor;
    GameObject track;
    GameObject stations;



    TextMeshProUGUI scaleLabel;
    float scaleNum;
    Slider scaleBar;
    float playerHeight;

    AudioSource sound;
    AudioSource bgm1;
    AudioSource bgm2;
    Renderer[] trackRenderers;
    Renderer[] stationRenderers;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player");
        environment = GameObject.Find("Environment");

        bigParticles = GameObject.Find("BigParticles");
        bigParticles.SetActive(false);
        
        centerEyeAnchor = GameObject.Find("CenterEyeAnchor");

        track = GameObject.Find("Track");
        stations = GameObject.Find("Stations");

        trackRenderers = track.GetComponentsInChildren<Renderer>();
        stationRenderers = stations.GetComponentsInChildren<Renderer>();
        foreach(Renderer r in trackRenderers)
            r.enabled = false;
        foreach(Renderer r in stationRenderers)
            r.enabled = false;
        
        sound = GetComponent<AudioSource>();
        bgm1 = GameObject.Find("BGM1").GetComponent<AudioSource>();
        bgm2 = GameObject.Find("BGM2").GetComponent<AudioSource>();

        scaleLabel = GameObject.Find("ScaleLabel").GetComponent<TextMeshProUGUI>();
        scaleBar = GameObject.Find("ScaleBar").GetComponent<Slider>();
        scaleBar.value = 0f;


    }

    // Update is called once per frame
    void Update()
    {
        if(activateChangeScale == true){
            playerHeight = centerEyeAnchor.transform.localPosition.y;
            int feet = (int)(playerHeight * 3.28084f);
            int inches = (int)(((playerHeight*3.28084f)%1)*12);
            //scaleLabel.text = "Your Height is: " + feet + " feet " + inches + " inches";
        }

        /*
        if(activateChangeScale == true){
            StartCoroutine(changeScale());
            activateChangeScale = false;
        }
        */
    }

    public void ShrinkStart(){
        if(activateChangeScale == true){
            StartCoroutine(changeScale());
            activateChangeScale = false;
        }
    }


    IEnumerator changeScale(){
        //yield return new WaitForSeconds(7f);
		float currentPlayerHeight;
		
        Vector3 currentScale = normalScale;

        this.transform.position = player.transform.position;
        //this.transform.position = environment.transform.position;
        this.transform.position = this.transform.position + new Vector3(0f,-0.3f,0f);

        environment.transform.parent = this.transform;
        //environment.transform.localPosition = new Vector3(0f,-0.005f,0f);

        
           float t = 0f;
        sound.Play(0);
        while(t < duration){


            //scene transition
            if(t > 1.7f){
                centerEyeAnchor.GetComponent<OVRScreenFade>().FadeOut();
                yield return new WaitForSeconds(2f);
                bigParticles.SetActive(true);

                foreach(Renderer r in trackRenderers)
                    r.enabled = true;
                foreach(Renderer r in stationRenderers)
                    r.enabled = true;


                environment.SetActive(false);
				RenderSettings.skybox = (null);
                centerEyeAnchor.GetComponent<OVRScreenFade>().FadeIn();
                currentPlayerHeight = playerHeight * 1.4f;
                //scaleLabel.color = new Color32(0,0,0,255);
                //scaleLabel.text = "Your Height is: " + currentPlayerHeight.ToString("F3") + " micrometers";
                bgm1.Stop();
                yield return new WaitForSeconds(5f);
                bgm2.Play();
                break;
            }

            currentScale = Vector3.Lerp(normalScale, largeScale, t/duration);

            transform.localScale = currentScale;
            t = t + 0.01f;

            currentPlayerHeight = playerHeight * (normalScale.x / currentScale.x);
            //scaleLabel.text = "Your Height is: " + currentPlayerHeight + "m";
            int feet = (int)(currentPlayerHeight * 3.28084f);
            int inches = (int)(((currentPlayerHeight*3.28084f)%1)*12);
            //scaleLabel.text = "Your Height is: " + feet + " feet " + inches + " inches";


            scaleBar.value += 0.0059f;
            yield return new WaitForSeconds(0.01f);
        }
		
		
    }
}
