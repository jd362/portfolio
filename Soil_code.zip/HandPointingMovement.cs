using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandPointingMovement : MonoBehaviour
{

    [SerializeField]
	GameObject _rightHand;
	
	[SerializeField]
	GameObject _leftHand;

    [SerializeField]
	GameObject _centerEyeAnchor;

    private WIDVE.Paths.PathPosition pathPosition;
    private GameObject player;
    private VBTesting.PlayerMovement playerMovement;


    Vector3 _avgPositionRight = Vector3.zero;
	Vector3 _avgDirectionRight = Vector3.zero;
    Vector3 _avgDirectionLeft = Vector3.zero;
	
	int _currPosition = 0;
	
	OVRHand _handTracker = null;


    // Start is called before the first frame update
    void Start()
    {
        if(_rightHand != null)
		{
			_handTracker = _rightHand.transform.GetChild(1).GetComponent<OVRHand>();
		}
        player = GameObject.Find("Player");
        pathPosition = player.GetComponent<WIDVE.Paths.PathPosition>();
        playerMovement = GameObject.Find("Movement").GetComponent<VBTesting.PlayerMovement>();
    }

    // Update is called once per frame
    void Update()
    {
		//bool positionLocked = (playerMovement.CurrentPlayerState() == "VBTesting.PlayerMovement+States+FrozenTrack");
        //Debug.Log(playerMovement.CurrentPlayerState());
        if(_handTracker.IsTracked && _handTracker.IsDataHighConfidence)
		{
            //RaycastHit hitInfo;
            
            Vector3 castOrigin = _rightHand.transform.position - _rightHand.transform.forward*0.025f;// - _rightHand.transform.right*0.11f - _rightHand.transform.forward*0.025f - _rightHand.transform.up * 0.075f;
            
            //_avgPosition += castOrigin;
            _avgDirectionRight += ((-_rightHand.transform.right - _rightHand.transform.up) * 0.5f);
            _avgDirectionLeft += ((-_leftHand.transform.right - _leftHand.transform.up) * 0.5f);
            _currPosition++;
            if(_currPosition == 10)
            {
                _currPosition = 1;
            }
            
            _avgPositionRight =  _rightHand.transform.position;

            _avgDirectionRight /= (float)_currPosition;
            _avgDirectionRight = Vector3.Normalize(_avgDirectionRight);
            _avgDirectionLeft /= (float)_currPosition;
            _avgDirectionLeft = Vector3.Normalize(_avgDirectionLeft);
            //Debug.Log(_avgDirection);
            //Debug.Log(_avgDirection.x);

            Vector3 faceDirection = Vector3.Normalize(_centerEyeAnchor.transform.forward);
            //Debug.Log(Vector3.Dot(_avgDirection, faceDirection));

            Vector3 pathDirection = pathPosition.GetPathDirection(pathPosition.getPosition);
            pathDirection = Vector3.Normalize(pathDirection);
            //Debug.Log(pathDirection);
            //Debug.Log(Vector3.Dot(pathDirection, faceDirection));

            /*
            if(Vector3.Dot(_avgDirection, faceDirection) >0.4f && Vector3.Dot(_avgDirection, faceDirection)<0.75f){
                pathPosition.getPosition += 0.0001f;
                pathPosition.SetPosition(pathPosition.Position, true);
            }
            */

            //move if pointing and looking at path direction
            /*
            if((Vector3.Dot(_avgDirection, faceDirection) >0.4f && Vector3.Dot(_avgDirection, faceDirection)<0.75f)
            && (Vector3.Dot(pathDirection, faceDirection) >0.8f && Vector3.Dot(pathDirection, faceDirection)<1f)){
                pathPosition.getPosition += 0.0001f;
                pathPosition.SetPosition(pathPosition.Position, true);
            }
            */

            //Debug.Log(_avgDirectionLeft);
            //Debug.Log(faceDirection);
            //Debug.Log((Vector3.Dot(_avgDirectionLeft, faceDirection)));
            
			//faceDirection.y = 0;
            //_avgDirectionRight.y = 0;
            //_avgDirectionLeft.y = 0;

            //Debug.Log(playerMovement.CurrentPlayerState());
            if(playerMovement.CurrentPlayerState() != "VBTesting.PlayerMovement+States+FrozenTrack")
			{
                if((Vector3.Dot(_avgDirectionLeft, faceDirection) < -0.5f) && (Vector3.Dot(_avgDirectionRight, faceDirection) > 0.5f)
                && Vector3.Dot(pathDirection, faceDirection) > 0.6){
                    pathPosition.getPosition += (0.01f * UnityEngine.Time.deltaTime);
                    pathPosition.SetPosition(pathPosition.Position, true);
                }
                /*else if((Vector3.Dot(_avgDirectionLeft, faceDirection) < -0.5f) && (Vector3.Dot(_avgDirectionRight, faceDirection) > 0.5f)
                && Vector3.Dot(pathDirection, faceDirection) < -0.6){
                    pathPosition.getPosition -= (0.01f * UnityEngine.Time.deltaTime);
                    pathPosition.SetPosition(pathPosition.Position, true);
                }*/
            }

        }
        
    }
}
